document.addEventListener('DOMContentLoaded', function() {
    new kursor({
        type: 4,
        removeDefaultCursor: true // Whether to remove the default cursor
    });
    
});

