// contentScript.js
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "restoreInitialState") {
      // Restore the initial state by reloading the page
      location.reload();
      // Alternatively, you can set document.documentElement.innerHTML to the initial state if you have it stored somewhere.
      sendResponse("Initial state restored.");
    }
  });
  