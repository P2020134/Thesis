chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === 'adjustFontSize') {
    adjustFontSize(request.value);
  }
});

function adjustFontSize(value) {
  const currentSize = parseInt(window.getComputedStyle(document.body, null).getPropertyValue('font-size'));
  let newSize;

  if (value === 'larger') {
    newSize = currentSize + 2;
  } else if (value === 'smaller') {
    newSize = currentSize - 2;
  }

  document.body.style.fontSize = `${newSize}px`;
}



const port = chrome.runtime.connect({ name: "content-script" });

// Send a message to the background script to get the tabId
port.postMessage({ action: 'getTabId' });

port.onMessage.addListener(function (msg) {
  const originalTabId = msg.tabId;
  console.log("Original Tab ID:", originalTabId);
});