chrome.runtime.onInstalled.addListener((e) => {
  if (e.reason === chrome.runtime.OnInstalledReason.INSTALL) {

    chrome.runtime.setUninstallURL(
      "https://forms.gle/TwXH77zFgNnfY1rX6" //unistall page 
    )

    chrome.tabs.create({
      url: "onboardingsite/onboarding.html" //onboarding page
    })
  }
})




function installScript(details){
  // console.log('Installing content script in all tabs.');
  let params = {
      currentWindow: true
  };
  chrome.tabs.query(params, function gotTabs(tabs){
      let contentjsFile = chrome.runtime.getManifest().content_scripts[0].js[0];
      for (let index = 0; index < tabs.length; index++) {
          chrome.tabs.executeScript(tabs[index].id, {
              file: contentjsFile
          },
          result => {
              const lastErr = chrome.runtime.lastError;
              
          })
      }
  });    
}


let currentTabId;

chrome.runtime.onConnect.addListener(function (port) {
  if (port.name === "content-script") {
    port.onMessage.addListener(function (msg) {
      if (msg.action === 'getTabId') {
        currentTabId = port.sender.tab.id;
        port.postMessage({ tabId: currentTabId });
      }
    });
  }
});



