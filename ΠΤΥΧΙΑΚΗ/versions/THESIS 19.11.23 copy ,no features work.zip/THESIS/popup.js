
window.onload=function(){
  // popup.js
document.getElementById('adjustButton').addEventListener('click', function() {
  chrome.windows.create({
    url: 'adjustpopup.html',
    type: 'popup',
    width: 300,
    height: 200,
  });
});

}

