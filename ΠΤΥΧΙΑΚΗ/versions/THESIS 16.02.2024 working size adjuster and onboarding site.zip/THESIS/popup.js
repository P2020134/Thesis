document.addEventListener('DOMContentLoaded', function () {
  var increaseButton = document.getElementById('increaseButton');
  var decreaseButton = document.getElementById('decreaseButton');

  increaseButton.addEventListener('click', function () {
    adjustFontSize(2); // Increase font size by 2 pixels
  });

  decreaseButton.addEventListener('click', function () {
    adjustFontSize(-2); // Decrease font size by 2 pixels
  });

  function adjustFontSize(change) {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: function(change) {
          // Select all text-containing elements on the page (paragraphs, headings, spans, etc.)
          let textElements = document.querySelectorAll('p, h1, h2, h3, h4, h5, h6, span');
          // Loop through each text-containing element
          textElements.forEach(function(element) {
            // Get the computed style of the element
            let computedStyle = window.getComputedStyle(element);
            // Get the font size property from the computed style
            let fontSize = computedStyle.fontSize;
            // Parse the font size to extract the numeric value (remove "px" or "em" units)
            let numericFontSize = parseFloat(fontSize);
            // Adjust the font size by the specified amount
            let adjustedFontSize = numericFontSize + change;
            // Apply the adjusted font size to the element
            element.style.fontSize = adjustedFontSize + 'px';
          });
        },
        args: [change]
      });
    });
  }
});
