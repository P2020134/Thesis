chrome.runtime.onInstalled.addListener((e) => {
  if (e.reason === chrome.runtime.OnInstalledReason.INSTALL) {

    chrome.runtime.setUninstallURL(
      "https://forms.gle/TwXH77zFgNnfY1rX6" //unistall page 
    )

    chrome.tabs.create({
      url: "onboardingsite/onboarding1.1.html" //onboarding page
    })
  }
})


chrome.action.onClicked.addListener((tab) => {
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: increaseFontSize
  });
});

function increaseFontSize() {
  const bodyComputedStyle = window.getComputedStyle(document.body);
  const currentFontSize = parseInt(bodyComputedStyle.getPropertyValue('font-size'));

  // Increase font size by +2 pixels
  const newFontSize = currentFontSize + 2;
  document.body.style.fontSize = `${newFontSize}px`;
}



