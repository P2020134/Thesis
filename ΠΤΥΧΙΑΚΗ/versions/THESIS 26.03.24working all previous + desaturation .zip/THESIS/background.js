chrome.runtime.onInstalled.addListener((e) => {
  if (e.reason === chrome.runtime.OnInstalledReason.INSTALL) {

    chrome.runtime.setUninstallURL(
      "https://forms.gle/TwXH77zFgNnfY1rX6" //unistall page 
    )

    chrome.tabs.create({
      url: "onboardingsite/onboarding1.1.html" //onboarding page
    })
  }
})




// background.js
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "saveInitialState") {
    // Save the initial state in Chrome storage
    chrome.storage.local.set({ initialState: message.initialState }, () => {
      console.log("Initial state saved:", message.initialState);
    });
  }
});




