// Function to adjust font size
function adjustFontSize(change) {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: function (change) {
        // Select all text-containing elements on the page (paragraphs, headings, spans, etc.)
        let textElements = document.querySelectorAll('p, h1, h2, h3, h4, h5, h6, span');
        // Loop through each text-containing element
        textElements.forEach(function (element) {
          // Get the computed style of the element
          let computedStyle = window.getComputedStyle(element);
          // Get the font size property from the computed style
          let fontSize = computedStyle.fontSize;
          // Parse the font size to extract the numeric value (remove "px" or "em" units)
          let numericFontSize = parseFloat(fontSize);
          // Adjust the font size by the specified amount
          let adjustedFontSize = numericFontSize + change;
          // Apply the adjusted font size to the element
          element.style.fontSize = adjustedFontSize + 'px';
        });
      },
      args: [change]
    });
  });
}

// Function to remove images
function removeImages() {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: function () {
        // Remove images and videos by setting display: none
        document.querySelectorAll('img, video').forEach(element => element.style.display = 'none');
      }
    });
  });
}

// Function to restore initial state
function restoreInitialState() {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    var tab = tabs[0];
    // Check if the tab has finished loading and if the content script is ready
    if (tab.status === 'complete') {
      chrome.tabs.sendMessage(tab.id, { action: "restoreInitialState" }, function (response) {
        if (!response) {
          console.log("Failed to send message to content script.");
        }
      });
    } else {
      console.log("Tab is not fully loaded yet. Try again later.");
    }
  });
}

// Function to enlarge cursor
function enlargeCursor() {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    chrome.tabs.sendMessage(tabs[0].id, { action: "enlargeCursor" });
  });
}

function toggleDesaturation() {
  console.log("Sending message to toggle desaturation...");
  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    chrome.tabs.sendMessage(tabs[0].id, { command: "toggleDesaturation" }, function(response) {
      if (chrome.runtime.lastError) {
        console.error("Error sending message:", chrome.runtime.lastError.message);
      } else {
        console.log("Message sent successfully:", response);
      }
    });
  });
}



document.addEventListener('DOMContentLoaded', function () {
  // Initialization
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    var tabId = tabs[0].id;
    var increaseButton = document.getElementById('increaseButton');
    var decreaseButton = document.getElementById('decreaseButton');
    var removeImagesButton = document.getElementById('removeImagesButton');
    var revertButton = document.getElementById('revertButton');
    var enlargeButton = document.getElementById('enlargeCursorButton');
    var SaturationButton= document.getElementById("SaturationButton");

    // Event listeners
    increaseButton.addEventListener('click', function () {
      adjustFontSize(2); // Increase font size by 2 pixels
    });

    decreaseButton.addEventListener('click', function () {
      adjustFontSize(-2); // Decrease font size by 2 pixels
    });

    removeImagesButton.addEventListener('click', function () {
      removeImages();
    });

    revertButton.addEventListener('click', function () {
      restoreInitialState();
    });

    enlargeButton.addEventListener('click', function () {
      enlargeCursor();
    });

    SaturationButton.addEventListener("click", toggleDesaturation);
  });
});
